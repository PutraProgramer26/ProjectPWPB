<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('startups.create')); ?>" class="btn btn-primary">Add New</a>
<table class="table">
<tr>
<th>ID</th>
<th>Image</th>
<th>Name</th>
<th>Ceo</th>
<th>Country</th>
<th>Action</th>
</tr>
<?php $__currentLoopData = $startups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $startup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($startup->id); ?></td>
<td><img src="<?php echo e(Storage::url('public/images/' . $startup->image)); ?>" alt=""
style="width: 150px;"></td>
<td><?php echo e($startup->name); ?></td>
<td><?php echo e($startup->ceo); ?></td>
<td><?php echo e($startup->country); ?></td>
<td>
<a href="<?php echo e(route('startups.show', $startup->id)); ?>" class="btn btnsuccess">Show</a>
<a href="<?php echo e(route('startups.edit', $startup->id)); ?>" class="btn btnwarning">Edit</a>
<form onclick="return confirm('Are you sure?')"
action="<?php echo e(route('startups.destroy', $startup->id)); ?>" method="post"
style="display:inline;">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button class="btn btn-danger">Delete</button>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($startups->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('startups.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_startup/resources/views/startups/index.blade.php ENDPATH**/ ?>