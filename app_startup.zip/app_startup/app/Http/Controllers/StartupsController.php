<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Startup;
use Illuminate\Support\Facades\Storage;

class StartupsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $startups = Startup::paginate(2);
return view('startups.index', ['startups' => $startups ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('startups.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'ceo' => 'required',
            'country' => 'required',
            'image' => 'required|image|mimes:jpg,jpeg,png,svg,gif|max:2048']);
            $image = $request->file('image');
$image->storeAs('public/images/', $image->hashName());
Startup::create([
    'name' => $request->name,
    'ceo' => $request->ceo,
    'country' => $request->country,
    'image' => $image->hashName(),
    ]);
    return redirect()->route('startups.index')->with('success','Startup uploaded
successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Startup $startup)
    {
        return view('startups.show', [ 'startup' => $startup ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Startup $startup)
    {
        return view('startups.edit', [ 'startup' => $startup ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Startup $startup)
    {
        $request->validate([
            'name' => 'required',
            'ceo' => 'required',
            'country' => 'required',
            ]);
            if ($request->has('image')) {
                $image = $request->file('image');
                $image->storeAs('public/images/', $image->hashName());
                Storage::delete('public/images/' . $startup→image);

                $startup->update([
                    'name' => $request->name,
                    'ceo' => $request->ceo,
                    'country' => $request->country,
                    'image' => $image->hashName(),
                    ]);
                    } else {
                    $startup->update([
                    'name' => $request->name,
                    'ceo' => $request->ceo,
                    'country' => $request->country,
                    ]);
                }
                return redirect()->route('startups.index')->with('success','Startup updated
successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Startup $startup)
    {
        Storage::delete('public/images/' . $startup->image);
$startup->delete();
return redirect()->route('startups.index')->with('success', 'Startup deleted
successfully');
    }}
