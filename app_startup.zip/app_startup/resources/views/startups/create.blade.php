@extends('startups.layout')
@section('content')
<form action="{{ route('startups.store') }}" method="post"
enctype="multipart/form-data" class="form">
@csrf
<label for="">Name</label><br>
<input type="text" name="name" id=""><br>
<label for="">Ceo</label><br>
<input type="text" name="ceo" id=""><br>
<label for="">Country</label><br>
<input type="text" name="country" id=""><br>
<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>
<input type="submit" value="Save" class="btn btn-primary">
</form>

@endsection
