@extends('startups.layout')
@section('content')
<form action="{{ route('startups.update', $startup->id) }}" method="post"
enctype="multipart/form-data" class="form">
@csrf
@method('PUT')
<label for="">Name</label><br>
<input type="text" name="name" id="" value="{{ $startup->name }}"><br>
<label for="">Ceo</label><br>
<input type="text" name="ceo" id="" value="{{ $startup->ceo }}"><br>
<label for="">Country</label><br>
<input type="text" name="country" id="" value="{{ $startup->country }}"><br>
<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>
<input type="submit" value="Update" class="btn btn-primary">
</form>
@endsection