@extends('travels.layout')
@section('content')

<img src="{{ Storage::url('public/images/' . $travel->image) }}" alt="" style="width: 500px;">
<p>Nama : {{ $travel->nama }}</p>
<p>Kota : {{ $travel->kota }}</p>
<p>Harga Tiket : {{ $travel->harga_tiket }}</p>


<a href="{{ route('travels.index') }}"><button class="btn btn-secondary">BACK</button></a>
@endsection
 