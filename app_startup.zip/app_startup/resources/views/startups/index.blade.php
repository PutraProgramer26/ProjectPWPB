@extends('startups.layout')
@section('content')
<a href="{{ route('startups.create') }}" class="btn btn-primary">Add New</a>
<table class="table">
<tr>
<th>ID</th>
<th>Image</th>
<th>Name</th>
<th>Ceo</th>
<th>Country</th>
<th>Action</th>
</tr>
@foreach ($startups as $startup)
<tr>
<td>{{ $startup->id }}</td>
<td><img src="{{ Storage::url('public/images/' . $startup->image) }}" alt=""
style="width: 150px;"></td>
<td>{{ $startup->name }}</td>
<td>{{ $startup->ceo }}</td>
<td>{{ $startup->country }}</td>
<td>
<a href="{{ route('startups.show', $startup->id) }}" class="btn btnsuccess">Show</a>
<a href="{{ route('startups.edit', $startup->id) }}" class="btn btnwarning">Edit</a>
<form onclick="return confirm('Are you sure?')"
action="{{ route('startups.destroy', $startup->id) }}" method="post"
style="display:inline;">
@csrf
@method('DELETE')
<button class="btn btn-danger">Delete</button>
</form>
</td>
</tr>
@endforeach
</table>
{{ $startups->links() }}
@endsection