@extends('travels.layout')
@section('content')
<form action="{{ route('travels.store') }}" method="post" enctype="multipart/form-data"><br>
    <h3 class="text-center">ADD NEW TRAVEL</h3><br>
    @csrf
    <label for="">Nama</label><br>
    <input type="text" name="nama" id="" class="form-control"><br>
    <label for="">Kota</label><br>
    <input type="text" name="kota" id="" class="form-control"><br>
    <label for="">Harga Tiket</label><br>
    <input type="number" name="harga_tiket" id="" class="form-control"><br>
    <label for="">Upload Image</label><br>
    <input type="file" name="image" id=""><br><br>
    <input type="submit" value="SAVE" class="btn btn-success"><br>
</form>
@endsection
