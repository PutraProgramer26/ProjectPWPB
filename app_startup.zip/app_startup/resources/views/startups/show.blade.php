@extends('startups.layout')
@section('content')
<img src="{{ Storage::url('public/images/' . $startup->image) }}" alt=""
style="width: 500px">
<br><br>
<h3>{{ $startup->name }}</h3>
<p>{{ $startup->country }}</p>
<p>{{ $startup->image }}</p>
<a href="{{ route('startups.index') }}" class="btn btn-secondary">Back to
Index</a>
@endsection