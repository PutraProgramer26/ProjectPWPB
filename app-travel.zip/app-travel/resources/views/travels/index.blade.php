@extends('travels.layout')
@section('content')
<a href="{{ route('travels.create') }}"><button class="btn btn-primary">ADD NEW</button></a><br><br>
<table class="table table-bordered bordered-dark table-hover table-stripped">
    <tr class="table table-dark text-center">
        <th>ID</th>
        <th>Image</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Action</th>
    </tr>
    @foreach ($travels as $travel )
    <tr>
        <td class="text-center">{{ $travel->id }}</td>
        <td><img src="{{ Storage::url('public/images/' . $travel->image) }}" alt="" style="width: 150px;"></td>
        <td class="text-center">{{ $travel->nama }}</td>  
        <td class="text-center">{{ $travel->kota }}</td>  
        <td class="text-center">{{ $travel->harga_tiket }}</td>    
        <td class="text-center">
        <a href="{{ route('travels.show', $travel->id) }}"><button class="btn btn-primary">SHOW</button></a>
        <a href="{{ route('travels.edit', $travel->id) }}"><button class="btn btn-warning">EDIT</button></a>
        <form action="{{ route('travels.destroy', $travel->id) }}" method="post" style="display: inline"
             onclick="return confirm('Are You Sure?')">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger">DELETE</button>
        </form>
        </td>  
    </tr>        
    @endforeach
</table>

{{ $travels->links() }}
@endsection
