
<?php $__env->startSection('content'); ?>

<img src="<?php echo e(Storage::url('public/images/' . $travel->image)); ?>" alt="" style="width: 500px;">
<p>Nama : <?php echo e($travel->nama); ?></p>
<p>Kota : <?php echo e($travel->kota); ?></p>
<p>Harga Tiket : <?php echo e($travel->harga_tiket); ?></p>


<a href="<?php echo e(route('travels.index')); ?>"><button class="btn btn-secondary">BACK</button></a>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This\app-travel\resources\views/travels/show.blade.php ENDPATH**/ ?>