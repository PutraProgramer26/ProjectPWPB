<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('startups.store')); ?>" method="post"
enctype="multipart/form-data" class="form">
<?php echo csrf_field(); ?>
<label for="">Name</label><br>
<input type="text" name="name" id=""><br>
<label for="">Ceo</label><br>
<input type="text" name="ceo" id=""><br>
<label for="">Country</label><br>
<input type="text" name="country" id=""><br>
<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>
<input type="submit" value="Save" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('startup.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_startup/resources/views/startup/create.blade.php ENDPATH**/ ?>