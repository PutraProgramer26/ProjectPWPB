
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('travels.create')); ?>"><button class="btn btn-primary">ADD NEW</button></a><br><br>
<table class="table table-bordered bordered-dark table-hover table-stripped">
    <tr class="table table-dark text-center">
        <th>ID</th>
        <th>Image</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Action</th>
    </tr>
    <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($travel->id); ?></td>
        <td><img src="<?php echo e(Storage::url('public/images/' . $travel->image)); ?>" alt="" style="width: 150px;"></td>
        <td class="text-center"><?php echo e($travel->nama); ?></td>  
        <td class="text-center"><?php echo e($travel->kota); ?></td>  
        <td class="text-center"><?php echo e($travel->harga_tiket); ?></td>    
        <td class="text-center">
        <a href="<?php echo e(route('travels.show', $travel->id)); ?>"><button class="btn btn-primary">SHOW</button></a>
        <a href="<?php echo e(route('travels.edit', $travel->id)); ?>"><button class="btn btn-warning">EDIT</button></a>
        <form action="<?php echo e(route('travels.destroy', $travel->id)); ?>" method="post" style="display: inline"
             onclick="return confirm('Are You Sure?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">DELETE</button>
        </form>
        </td>  
    </tr>        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo e($travels->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This\app-travel\resources\views/travels/index.blade.php ENDPATH**/ ?>