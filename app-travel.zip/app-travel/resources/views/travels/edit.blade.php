@extends('travels.layout')
@section('content')
<form action="{{ route('travels.update', $travel->id) }}" method="post" enctype="multipart/form-data"><br>
    <h3 class="text-center">UPDATE TRAVEL</h3><br>
    @csrf
    @method('PUT')
    <label for="">Nama</label><br>
    <input type="text" name="nama" id="" class="form-control" value="{{ $travel->nama }}"><br>
    <label for="">Kota</label><br>
    <input type="text" name="kota" id="" class="form-control" value="{{ $travel->kota }}"><br>
    <label for="">Harga Tiket</label><br>
    <input type="number" name="harga_tiket" id="" class="form-control" value="{{ $travel->harga_tiket }}"><br>
    <label for="">Upload Image</label><br>
    <input type="file" name="image" id=""><br><br>
    <input type="submit" value="UPDATE" class="btn btn-success"><br>
</form>
@endsection
