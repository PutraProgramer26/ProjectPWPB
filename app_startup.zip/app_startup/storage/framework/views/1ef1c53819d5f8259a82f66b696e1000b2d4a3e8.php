<?php $__env->startSection('content'); ?>
<img src="<?php echo e(Storage::url('public/images/' . $startup->image)); ?>" alt=""
style="width: 500px">
<br><br>
<h3><?php echo e($startup->name); ?></h3>
<p><?php echo e($startup->country); ?></p>
<p><?php echo e($startup->image); ?></p>
<a href="<?php echo e(route('startups.index')); ?>" class="btn btn-secondary">Back to
Index</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('startups.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_startup/resources/views/startups/show.blade.php ENDPATH**/ ?>